package com.example.coursemanagement.controller;

import com.example.coursemanagement.models.CourseProgress;
import com.example.coursemanagement.service.CourseProgressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/progress")
public class CourseProgressController {

    @Autowired
    private CourseProgressService courseProgressService;

    // Get course progress for a student
    @GetMapping("/get/{userId}/{courseId}")
    public ResponseEntity<CourseProgress> getProgress(@PathVariable String userId, @PathVariable String courseId) {
        CourseProgress progress = courseProgressService.getProgress(userId, courseId);
        return progress != null ? ResponseEntity.ok(progress) : ResponseEntity.notFound().build();
    }

    // Update course progress
    @PostMapping("/update")
    public ResponseEntity<CourseProgress> updateProgress(@RequestBody CourseProgress progress) {
        CourseProgress updatedProgress = courseProgressService.updateProgress(progress);
        return ResponseEntity.ok(updatedProgress);
    }
}
