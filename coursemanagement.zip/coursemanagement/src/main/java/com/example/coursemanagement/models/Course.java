package com.example.coursemanagement.models;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "courses")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String instructorId;
    private String instructorName;
    private Date date;
    private String title;
    private String category;
    private String level;
    private String primaryLanguage;
    private String subtitle;
    private String description;
    private String image;
    private String welcomeMessage;
    private Double pricing;
    private String objectives;
    private Boolean isPublished;

    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL)
    private List<Student> students;

    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL)
    private List<Lecture> curriculum;

}
