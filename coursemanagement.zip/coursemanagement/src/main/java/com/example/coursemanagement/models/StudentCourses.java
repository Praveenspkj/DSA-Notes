package com.example.coursemanagement.models;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name = "student_courses")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
public class StudentCourses {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String userId;

    @OneToMany(mappedBy = "studentCourses", cascade = CascadeType.ALL)
    private List<StudentCourseEntry> courses;
}
