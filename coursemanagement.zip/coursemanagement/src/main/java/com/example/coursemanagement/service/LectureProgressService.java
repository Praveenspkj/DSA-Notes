package com.example.coursemanagement.service;
import com.example.coursemanagement.models.LectureProgress;
import com.example.coursemanagement.repositories.LectureProgressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LectureProgressService {

    @Autowired
    private LectureProgressRepository lectureProgressRepository;

    // Get lecture progress by course progress ID
    public List<LectureProgress> getLectureProgress(Long courseProgressId) {
        return lectureProgressRepository.findByCourseProgressId(courseProgressId);
    }

    // Mark lecture as viewed
    public LectureProgress markLectureAsViewed(LectureProgress lectureProgress) {
        return lectureProgressRepository.save(lectureProgress);
    }
}
