package com.example.coursemanagement.models;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Table(name = "course_enrollments")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
public class CourseEnrollment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String courseId;
    private String title;
    private String instructorId;
    private String instructorName;
    private Date dateOfPurchase;
    private String courseImage;
}
