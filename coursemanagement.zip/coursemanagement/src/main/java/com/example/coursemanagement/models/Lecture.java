package com.example.coursemanagement.models;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "lectures")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
public class Lecture {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String videoUrl;
    private String publicId;
    private Boolean freePreview;

    @ManyToOne
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;
}
