package com.example.coursemanagement.models;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Table(name = "lecture_progress")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
public class LectureProgress {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String lectureId;
    private Boolean viewed;
    private Date dateViewed;

    @ManyToOne
    @JoinColumn(name = "course_progress_id", nullable = false)
    private CourseProgress courseProgress;
}
