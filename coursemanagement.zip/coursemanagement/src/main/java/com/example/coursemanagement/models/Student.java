package com.example.coursemanagement.models;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "students")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String studentId;
    private String studentName;
    private String studentEmail;
    private Double paidAmount;

    @ManyToOne
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;
}
