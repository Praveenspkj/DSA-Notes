package com.example.coursemanagement.controller;

import com.example.coursemanagement.models.StudentCourses;
import com.example.coursemanagement.service.StudentCoursesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/student-courses")
public class StudentCoursesController {

    @Autowired
    private StudentCoursesService studentCoursesService;

    // Get courses by student ID
    @GetMapping("/get/{studentId}")
    public ResponseEntity<StudentCourses> getCoursesByStudentId(@PathVariable String studentId) {
        StudentCourses studentCourses = studentCoursesService.getCoursesByStudentId(studentId);
        return studentCourses != null ? ResponseEntity.ok(studentCourses) : ResponseEntity.notFound().build();
    }

    // Enroll student in a new course
    @PostMapping("/enroll")
    public ResponseEntity<StudentCourses> enrollStudent(@RequestBody StudentCourses studentCourses) {
        StudentCourses enrolledCourses = studentCoursesService.enrollStudentInCourse(studentCourses);
        return ResponseEntity.ok(enrolledCourses);
    }
}
