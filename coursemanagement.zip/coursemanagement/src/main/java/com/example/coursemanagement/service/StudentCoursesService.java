package com.example.coursemanagement.service;

import com.example.coursemanagement.models.StudentCourses;
import com.example.coursemanagement.repositories.StudentCoursesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentCoursesService {

    @Autowired
    private StudentCoursesRepository studentCoursesRepository;

    // Get courses by student ID
    public StudentCourses getCoursesByStudentId(String studentId) {
        return studentCoursesRepository.findByUserId(studentId);
    }

    // Enroll a student in a course
    public StudentCourses enrollStudentInCourse(StudentCourses studentCourses) {
        return studentCoursesRepository.save(studentCourses);
    }
}
