package com.example.coursemanagement.service;

import com.example.coursemanagement.models.Course;
import com.example.coursemanagement.repositories.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    // Add a new course
    public Course addCourse(Course course) {
        return courseRepository.save(course);
    }

    // Get all courses
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    // Get courses by instructor ID
    public List<Course> getCoursesByInstructor(String instructorId) {
        return courseRepository.findByInstructorId(instructorId);
    }

    // Get course details by ID
    public Optional<Course> getCourseById(Long courseId) {
        return courseRepository.findById(courseId);
    }

    // Update a course by ID
    public Course updateCourse(Long courseId, Course updatedCourse) {
        if (courseRepository.existsById(courseId)) {
            updatedCourse.setId(courseId);
            return courseRepository.save(updatedCourse);
        }
        return null;
    }
}
