package com.example.coursemanagement.repositories;

import com.example.coursemanagement.models.CourseProgress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CourseProgressRepository extends JpaRepository<CourseProgress, Long> {
    CourseProgress findByUserIdAndCourseId(String userId, String courseId);
}
