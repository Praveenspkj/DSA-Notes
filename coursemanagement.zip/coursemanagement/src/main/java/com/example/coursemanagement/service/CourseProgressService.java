package com.example.coursemanagement.service;
import com.example.coursemanagement.models.CourseProgress;
import com.example.coursemanagement.repositories.CourseProgressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseProgressService {

    @Autowired
    private CourseProgressRepository courseProgressRepository;

    // Get progress of a student in a specific course
    public CourseProgress getProgress(String userId, String courseId) {
        return courseProgressRepository.findByUserIdAndCourseId(userId, courseId);
    }

    // Update or create course progress
    public CourseProgress updateProgress(CourseProgress progress) {
        return courseProgressRepository.save(progress);
    }
}
