package com.example.coursemanagement.service;

import com.example.coursemanagement.models.Student;
import com.example.coursemanagement.repositories.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    // Get students by course ID
    public List<Student> getStudentsByCourseId(Long courseId) {
        return studentRepository.findByCourseId(courseId);
    }

    // Enroll a student in a course
    public Student enrollStudentInCourse(Student student) {
        return studentRepository.save(student);
    }
}
