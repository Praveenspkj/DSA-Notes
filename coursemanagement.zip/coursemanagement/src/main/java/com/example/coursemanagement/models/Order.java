package com.example.coursemanagement.models;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Table(name = "orders")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String userId;
    private String userName;
    private String userEmail;
    private String orderStatus;
    private String paymentMethod;
    private String paymentStatus;
    private Date orderDate;
    private String paymentId;
    private String payerId;
    private String instructorId;
    private String instructorName;
    private String courseImage;
    private String courseTitle;
    private String courseId;
    private Double coursePricing;
}
