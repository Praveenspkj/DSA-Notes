package com.example.coursemanagement.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name = "student_course_entries")
@AllArgsConstructor
@NoArgsConstructor
public class StudentCourseEntry {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String courseId;
    private String title;
    private String instructorId;
    private String instructorName;
    private Date dateOfPurchase;
    private String courseImage;

    @ManyToOne
    @JoinColumn(name = "student_courses_id", nullable = false)
    private StudentCourses studentCourses;

    // Getters and Setters
}
