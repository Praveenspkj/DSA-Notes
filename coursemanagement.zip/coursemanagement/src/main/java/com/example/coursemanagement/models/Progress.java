package com.example.coursemanagement.models;

public class Progress {
}
