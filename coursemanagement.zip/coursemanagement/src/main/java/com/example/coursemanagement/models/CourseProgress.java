package com.example.coursemanagement.models;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "progress")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
public class CourseProgress {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String userId;
    private String courseId;
    private Boolean completed;
    private Date completionDate;

    @OneToMany(mappedBy = "courseProgress", cascade = CascadeType.ALL)
    private List<LectureProgress> lecturesProgress;

}
